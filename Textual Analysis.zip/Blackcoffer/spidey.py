import pandas as pd
import scrapy
from ..items import BlackwaterItem



class PostsSpider(scrapy.Spider):
    name = "posts"
    df= pd.read_excel("Input.xlsx")
    samp = df["URL"].tolist()
    
    start_urls = samp
    # print(samp)
    cnt = 0 

    def parse(self, response):
        items = BlackwaterItem()
        # items['urllink']= response.url
        title = " ".join(response.xpath('//h1[@class="entry-title"]/text()').getall())
        para = " ".join(response.xpath('//div[@class="td-post-content"]/p/text()').getall())
        head = " ".join(response.xpath('//div[@class="td-post-content"]/h3/strong/text()').getall())
        # print(title)
        # print(para)
        # print(head)
        df = {'URL':response.url,
        'text':para,
        'title':title}
        df=pd.DataFrame(df,index=[0])
        maindf=pd.read_excel("./blackwater/spiders/Input.xlsx")
        df=df.merge(maindf,on=['URL'],how='left')
        df1=df['text']
        # df1.to_csv(str(df['URL_ID'][0])+'.txt',sep=' ', index=False, header=False)
        items['title'] = title
        items['para'] = para
        items['URL']=response.url
        items['URL_ID']=str(df['URL_ID'][0])

        yield items
